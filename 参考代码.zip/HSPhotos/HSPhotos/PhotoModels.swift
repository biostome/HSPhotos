import UIKit
import Photos

struct Album {
    let collection: PHAssetCollection
    let title: String
    let count: Int
    let coverImage: UIImage?
    var customOrder: [String] = [] // 存储照片的localIdentifier用于自定义排序
}

struct Photo {
    let asset: PHAsset
    let image: UIImage?
    let localIdentifier: String
    let creationDate: Date?
    var customOrderIndex: Int?
}

enum SortMode {
    case oldestFirst
    case newestFirst
    case custom
}

class PhotoDataManager {
    static let shared = PhotoDataManager()
    
    private init() {}
    
    func fetchAlbums(completion: @escaping ([Album]) -> Void) {
        let options = PHFetchOptions()
        options.sortDescriptors = [NSSortDescriptor(key: "title", ascending: true)]
        
        let collections = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: options)
        var albums: [Album] = []
        
        collections.enumerateObjects { collection, _, _ in
            let fetchOptions = PHFetchOptions()
            fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
            
            let assets = PHAsset.fetchAssets(in: collection, options: fetchOptions)
            
            if assets.count > 0 {
                let album = Album(
                    collection: collection,
                    title: collection.localizedTitle ?? "Unknown Album",
                    count: assets.count,
                    coverImage: nil
                )
                albums.append(album)
                
                // 异步获取封面图
                self.loadCoverImage(for: album, assets: assets) { coverImage in
                    if let index = albums.firstIndex(where: { $0.collection.localIdentifier == collection.localIdentifier }) {
                        albums[index] = Album(
                            collection: collection,
                            title: collection.localizedTitle ?? "Unknown Album",
                            count: assets.count,
                            coverImage: coverImage
                        )
                    }
                }
            }
        }
        
        completion(albums)
    }
    
    private func loadCoverImage(for album: Album, assets: PHFetchResult<PHAsset>, completion: @escaping (UIImage?) -> Void) {
        guard let firstAsset = assets.firstObject else {
            completion(nil)
            return
        }
        
        let options = PHImageRequestOptions()
        options.deliveryMode = .fastFormat
        options.isSynchronous = false
        
        PHImageManager.default().requestImage(
            for: firstAsset,
            targetSize: CGSize(width: 200, height: 200),
            contentMode: .aspectFill,
            options: options
        ) { image, _ in
            completion(image)
        }
    }
    
    func fetchPhotos(from collection: PHAssetCollection, sortMode: SortMode, completion: @escaping ([Photo]) -> Void) {
        let fetchOptions = PHFetchOptions()
        
        switch sortMode {
        case .oldestFirst:
            fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
        case .newestFirst:
            fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        case .custom:
            // 自定义排序：直接使用系统相册的顺序，因为我们已经通过moveAssets同步了排序
            // 不设置sortDescriptors，使用系统默认顺序
            break
        }
        
        let assets = PHAsset.fetchAssets(in: collection, options: fetchOptions)
        var photos: [Photo] = []
        
        assets.enumerateObjects { asset, index, _ in
            let photo = Photo(
                asset: asset,
                image: nil,
                localIdentifier: asset.localIdentifier,
                creationDate: asset.creationDate,
                customOrderIndex: nil
            )
            photos.append(photo)
        }
        
        // 如果是自定义排序，检查是否需要应用本地排序（兼容旧数据）
        if sortMode == .custom {
            let customOrder = getCustomOrder(for: collection)
            if !customOrder.isEmpty {
                // 如果本地有自定义排序数据，应用本地排序
                photos = applyCustomSort(to: photos, for: collection)
            }
        }
        
        // 异步加载图片
        loadImages(for: photos) { photosWithImages in
            completion(photosWithImages)
        }
    }
    
    private func loadImages(for photos: [Photo], completion: @escaping ([Photo]) -> Void) {
        let group = DispatchGroup()
        var photosWithImages = photos
        
        for (index, photo) in photos.enumerated() {
            group.enter()
            
            let options = PHImageRequestOptions()
            options.deliveryMode = .fastFormat
            options.isSynchronous = false
            
            PHImageManager.default().requestImage(
                for: photo.asset,
                targetSize: CGSize(width: 300, height: 300),
                contentMode: .aspectFill,
                options: options
            ) { image, _ in
                photosWithImages[index] = Photo(
                    asset: photo.asset,
                    image: image,
                    localIdentifier: photo.localIdentifier,
                    creationDate: photo.creationDate,
                    customOrderIndex: photo.customOrderIndex
                )
                group.leave()
            }
        }
        
        group.notify(queue: .main) {
            completion(photosWithImages)
        }
    }
    
    private func applyCustomSort(to photos: [Photo], for collection: PHAssetCollection) -> [Photo] {
        let customOrder = getCustomOrder(for: collection)
        
        if customOrder.isEmpty {
            return photos
        }
        
        // 创建自定义排序的照片数组
        var sortedPhotos: [Photo] = []
        var remainingPhotos = photos
        
        // 按照自定义顺序添加照片
        for photoId in customOrder {
            if let index = remainingPhotos.firstIndex(where: { $0.localIdentifier == photoId }) {
                var photo = remainingPhotos[index]
                photo.customOrderIndex = sortedPhotos.count
                sortedPhotos.append(photo)
                remainingPhotos.remove(at: index)
            }
        }
        
        // 将剩余照片添加到末尾
        for (index, photo) in remainingPhotos.enumerated() {
            var updatedPhoto = photo
            updatedPhoto.customOrderIndex = sortedPhotos.count + index
            sortedPhotos.append(updatedPhoto)
        }
        
        return sortedPhotos
    }
    
    func saveCustomOrder(_ photoIds: [String], for collection: PHAssetCollection) {
        // 保存到本地UserDefaults
        let key = "custom_order_\(collection.localIdentifier)"
        UserDefaults.standard.set(photoIds, forKey: key)
        
        // 使用新的排序管理器同步到系统相册
        PhotoSortManager.shared.sortPhotosInCollection(
            collection: collection,
            selectedPhotoIds: photoIds
        ) { success, errorMessage in
            if success {
                print("✅ 排序已同步到系统相册")
            } else {
                print("❌ 同步到系统相册失败: \(errorMessage ?? "未知错误")")
            }
        }
    }
    
    func getCustomOrder(for collection: PHAssetCollection) -> [String] {
        let key = "custom_order_\(collection.localIdentifier)"
        return UserDefaults.standard.stringArray(forKey: key) ?? []
    }
}
