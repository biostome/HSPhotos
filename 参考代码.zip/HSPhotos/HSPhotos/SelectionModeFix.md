# 选择模式排序保存逻辑修复

## 修复概述

修复了选择模式下拖拽排序的保存逻辑，确保拖拽后需要用户确认才能保存，并实现了两种不同的排序保存方式。

## 核心修复点

### 1. 添加拖拽状态跟踪
- 新增 `hasDraggedInCurrentSession` 变量跟踪当前选择会话中是否发生了拖拽
- 进入选择模式时重置此标志
- 拖拽操作时设置此标志为 `true`

### 2. 重构选择按钮逻辑
- 将原来的 `selectionButtonTapped()` 拆分为多个专门的方法
- `enterSelectionMode()`: 进入选择模式
- `handleDoneButtonTapped()`: 处理"完成"按钮点击
- `exitSelectionMode()`: 退出选择模式

### 3. 实现两种保存场景

#### 场景A：拖拽后保存 (`saveDraggedOrder()`)
- **触发条件**: `hasDraggedInCurrentSession == true`
- **执行逻辑**: 
  - 直接保存当前 `selectedPhotos` 的顺序
  - 自动切换为"按自定义顺序排序"
  - 退出选择模式
  - 显示同步通知

#### 场景B：锚点排序保存 (`saveAnchoredOrder()`)
- **触发条件**: `hasDraggedInCurrentSession == false` 且有选中照片
- **执行逻辑**:
  - 以第一张选中照片的原始位置为锚点
  - 锚点前的未选中照片保持原位
  - 所有选中照片按选择顺序排列在锚点位置
  - 剩余未选中照片排在选中照片后
  - 保存重排后的顺序

### 4. 修复拖拽管理器
- 拖拽时仅更新UI和设置拖拽标志
- 不立即保存排序结果
- 等待用户点击"完成"按钮确认

## 交互流程

### 拖拽场景
1. 用户点击"选择"按钮进入选择模式
2. 用户选择照片并拖拽调整位置
3. 拖拽过程中实时预览效果，序号重新编排
4. 用户点击"完成"按钮
5. 系统保存拖拽后的顺序并退出选择模式

### 非拖拽场景  
1. 用户点击"选择"按钮进入选择模式
2. 用户仅选择照片，不进行拖拽
3. 用户点击"完成"按钮
4. 系统按锚点规则重排照片并保存

## 技术实现细节

### 锚点排序算法
```swift
// 1. 添加锚点之前的未选中照片
for i in 0..<anchorIndex {
    if !selectedPhotos.contains(photo) {
        reorderedPhotos.append(photo)
    }
}

// 2. 按选择顺序添加所有选中照片
for selectedPhoto in selectedPhotos {
    reorderedPhotos.append(selectedPhoto)
}

// 3. 添加剩余的未选中照片
for photo in photos {
    if !processedIds.contains(photo.localIdentifier) {
        reorderedPhotos.append(photo)
    }
}
```

### 状态管理
- `isSelectionMode`: 是否处于选择模式
- `hasDraggedInCurrentSession`: 当前会话是否发生拖拽
- `selectedPhotos`: 当前选中的照片数组（保持选择顺序）

## 用户体验改进
- 拖拽后需要确认才保存，避免意外保存
- 两种排序方式满足不同使用场景
- 保持了原有的同步通知和确认对话框
- 状态管理更加清晰，交互逻辑更加合理
