import UIKit
import Photos

class PhotoGridViewController: UIViewController {
    
    private let album: Album
    var photos: [Photo] = []
    var selectedPhotos: [Photo] = []
    private var currentSortMode: SortMode = .newestFirst
    var isSelectionMode = false

    
    private let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 2
        layout.minimumLineSpacing = 2
        layout.sectionInset = UIEdgeInsets(top: 8, left: 8, bottom: 80, right: 8)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.97, alpha: 1.0)
        collectionView.register(PhotoCell.self, forCellWithReuseIdentifier: "PhotoCell")
        collectionView.showsVerticalScrollIndicator = false
        return collectionView
    }()
    
    private let sortButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "line.3.horizontal.decrease"), for: .normal)
        button.tintColor = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0)
        button.backgroundColor = .white
        button.layer.cornerRadius = 28
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 3)
        button.layer.shadowRadius = 8
        button.layer.shadowOpacity = 0.15
        button.layer.borderWidth = 0.5
        button.layer.borderColor = UIColor(red: 0.9, green: 0.9, blue: 0.92, alpha: 1.0).cgColor
        return button
    }()
    
    init(album: Album) {
        self.album = album
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupNavigationBar()
        setupSortPreferenceSync()
        loadPhotos()
    }
    
    private func setupUI() {
        view.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.97, alpha: 1.0)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView)
        
        sortButton.addTarget(self, action: #selector(sortButtonTapped), for: .touchUpInside)
        sortButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sortButton)
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            sortButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            sortButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -24),
            sortButton.widthAnchor.constraint(equalToConstant: 56),
            sortButton.heightAnchor.constraint(equalToConstant: 56)
        ])
    }
    
    private func setupNavigationBar() {
        title = album.title
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "选择", style: .plain, target: self, action: #selector(selectionButtonTapped))
        navigationItem.rightBarButtonItem?.tintColor = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0)
    }
    
    private func setupSortPreferenceSync() {
        // 设置排序偏好变更回调
        SortPreferenceManager.shared.onSortPreferenceChanged = { [weak self] newSortMode in
            self?.handleSystemSortPreferenceChange(newSortMode)
        }
        
        // 首次加载时读取系统排序偏好
        let systemSortMode = SortPreferenceManager.shared.getSystemSortPreference(for: album.collection)
        if systemSortMode != currentSortMode {
            currentSortMode = systemSortMode
            loadPhotos()
        }
    }
    
    private func loadPhotos() {
        PhotoDataManager.shared.fetchPhotos(from: album.collection, sortMode: currentSortMode) { [weak self] photos in
            DispatchQueue.main.async {
                self?.photos = photos
                self?.collectionView.reloadData()
            }
        }
    }
    
    @objc private func selectionButtonTapped() {
        if isSelectionMode {
            // 退出选择模式 - 点击"完成"按钮
            handleDoneButtonTapped()
        } else {
            // 进入选择模式 - 点击"选择"按钮
            enterSelectionMode()
        }
    }
    
    private func enterSelectionMode() {
        isSelectionMode = true
        navigationItem.rightBarButtonItem?.title = "完成"
        selectedPhotos.removeAll()
        collectionView.reloadData()
    }
    
    private func handleDoneButtonTapped() {
        if selectedPhotos.isEmpty {
            // 没有选中照片，直接退出选择模式
            exitSelectionMode()
            return
        }
        
        // 按锚点规则重排并保存
        saveAnchoredOrder()
    }
    
    private func exitSelectionMode() {
        isSelectionMode = false
        navigationItem.rightBarButtonItem?.title = "选择"
        selectedPhotos.removeAll()
        collectionView.reloadData()
    }
    
    @objc private func sortButtonTapped() {
        if #available(iOS 14.0, *) {
            // iOS 14+ 使用 Context Menu
            showContextMenuForButton()
        } else {
            // iOS 13 及以下的兼容实现
            showLegacySortOptions()
        }
    }
    
    @available(iOS 14.0, *)
    private func showContextMenuForButton() {
        // 使用现代的ActionSheet样式，模拟Context Menu的外观
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let options = [
            ("按最旧的排最前", SortMode.oldestFirst, "clock"),
            ("按最新的排最前", SortMode.newestFirst, "clock.badge.checkmark"),
            ("按自定义顺序排序", SortMode.custom, "list.number")
        ]
        
        for (title, mode, iconName) in options {
            let action = UIAlertAction(title: title, style: .default) { [weak self] _ in
                self?.changeSortMode(mode)
            }
            
            // 设置图标
            if #available(iOS 13.0, *) {
                action.setValue(UIImage(systemName: iconName), forKey: "image")
            }
            
            // 设置选中状态
            if mode == currentSortMode {
                action.setValue(UIImage(systemName: "checkmark"), forKey: "image")
            }
            
            alertController.addAction(action)
        }
        
        let cancelAction = UIAlertAction(title: "取消", style: .cancel)
        alertController.addAction(cancelAction)
        
        // 设置popover的源视图（iPad支持）
        if let popover = alertController.popoverPresentationController {
            popover.sourceView = sortButton
            popover.sourceRect = sortButton.bounds
            popover.permittedArrowDirections = .down
        }
        
        present(alertController, animated: true)
    }
    

    
    private func showLegacySortOptions() {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let options = [
            ("按最旧的排最前", SortMode.oldestFirst),
            ("按最新的排最前", SortMode.newestFirst),
            ("按自定义顺序排序", SortMode.custom)
        ]
        
        for (title, mode) in options {
            let action = UIAlertAction(title: title, style: .default) { [weak self] _ in
                self?.changeSortMode(mode)
            }
            if mode == currentSortMode {
                action.setValue(UIImage(systemName: "checkmark"), forKey: "image")
            }
            alertController.addAction(action)
        }
        
        let cancelAction = UIAlertAction(title: "取消", style: .cancel)
        alertController.addAction(cancelAction)
        
        alertController.popoverPresentationController?.sourceView = sortButton
        alertController.popoverPresentationController?.sourceRect = sortButton.bounds
        
        present(alertController, animated: true)
    }
    
    private func changeSortMode(_ mode: SortMode) {
        currentSortMode = mode
        
        // 同步排序偏好到系统相册
        SortPreferenceManager.shared.syncAppSortPreferenceToSystem(
            sortMode: mode,
            for: album.collection
        ) { [weak self] success, error in
            DispatchQueue.main.async {
                if success {
                    self?.showSortPreferenceSyncNotification()
                } else {
                    self?.showSortPreferenceSyncError()
                }
            }
        }
        
        loadPhotos()
    }
    
    private func handleSystemSortPreferenceChange(_ newSortMode: SortMode) {
        // 添加0.3秒过渡动画
        UIView.animate(withDuration: 0.3, animations: {
            self.collectionView.alpha = 0.5
        }) { _ in
            self.currentSortMode = newSortMode
            self.loadPhotos()
            
            UIView.animate(withDuration: 0.3) {
                self.collectionView.alpha = 1.0
            }
        }
    }
    
    // 按锚点规则重排并保存
    private func saveAnchoredOrder() {
        if currentSortMode != .custom {
            showSortModeChangeConfirmation { [weak self] in
                self?.performSaveAnchoredOrder()
            }
        } else {
            performSaveAnchoredOrder()
        }
    }
    
    private func performSaveAnchoredOrder() {
        // 实现锚点排序逻辑
        guard let firstSelectedPhoto = selectedPhotos.first else {
            exitSelectionMode()
            return
        }
        
        // 找到第一张选中照片在原始photos数组中的位置作为锚点
        guard let anchorIndex = photos.firstIndex(where: { $0.localIdentifier == firstSelectedPhoto.localIdentifier }) else {
            exitSelectionMode()
            return
        }
        
        var reorderedPhotos: [Photo] = []
        var processedIds = Set<String>()
        
        // 1. 添加锚点之前的未选中照片
        for i in 0..<anchorIndex {
            let photo = photos[i]
            if !selectedPhotos.contains(where: { $0.localIdentifier == photo.localIdentifier }) {
                reorderedPhotos.append(photo)
                processedIds.insert(photo.localIdentifier)
            }
        }
        
        // 2. 按选择顺序添加所有选中的照片
        for selectedPhoto in selectedPhotos {
            reorderedPhotos.append(selectedPhoto)
            processedIds.insert(selectedPhoto.localIdentifier)
        }
        
        // 3. 添加剩余的未选中照片
        for photo in photos {
            if !processedIds.contains(photo.localIdentifier) {
                reorderedPhotos.append(photo)
            }
        }
        
        // 保存重排后的顺序
        let photoIds = reorderedPhotos.map { $0.localIdentifier }
        PhotoDataManager.shared.saveCustomOrder(photoIds, for: album.collection)
        currentSortMode = .custom
        exitSelectionMode()
        
        // 延迟重新加载照片，确保系统相册的更改已经生效
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.loadPhotos()
        }
        
        showSyncNotification()
    }
    
    private func showSortModeChangeConfirmation(completion: @escaping () -> Void) {
        let alertController = UIAlertController(
            title: "更新排序",
            message: "会覆盖之前的自定义排序，要继续吗？",
            preferredStyle: .alert
        )
        
        let cancelAction = UIAlertAction(title: "取消", style: .cancel) { [weak self] _ in
            // 取消时保持选择模式
            self?.isSelectionMode = true
            self?.navigationItem.rightBarButtonItem?.title = "完成"
        }
        
        let continueAction = UIAlertAction(title: "继续", style: .default) { _ in
            completion()
        }
        continueAction.setValue(UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0), forKey: "titleTextColor")
        
        alertController.addAction(cancelAction)
        alertController.addAction(continueAction)
        
        present(alertController, animated: true)
    }
    
    private func showSyncNotification() {
        let syncLabel = UILabel()
        syncLabel.text = "已同步到原生相册"
        syncLabel.font = UIFont.systemFont(ofSize: 14)
        syncLabel.textColor = UIColor(red: 0.4, green: 0.4, blue: 0.45, alpha: 1.0)
        syncLabel.textAlignment = .center
        syncLabel.backgroundColor = UIColor(red: 0.9, green: 0.9, blue: 0.92, alpha: 1.0)
        syncLabel.layer.cornerRadius = 8
        syncLabel.clipsToBounds = true
        syncLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(syncLabel)
        
        NSLayoutConstraint.activate([
            syncLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            syncLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            syncLabel.heightAnchor.constraint(equalToConstant: 32),
            syncLabel.widthAnchor.constraint(equalToConstant: 200)
        ])
        
        syncLabel.alpha = 0
        UIView.animate(withDuration: 0.3, animations: {
            syncLabel.alpha = 1
        }) { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                UIView.animate(withDuration: 0.3, animations: {
                    syncLabel.alpha = 0
                }) { _ in
                    syncLabel.removeFromSuperview()
                }
            }
        }
    }
    
    private func showSortPreferenceSyncNotification() {
        let syncLabel = UILabel()
        syncLabel.text = "排序偏好已同步到系统相册"
        syncLabel.font = UIFont.systemFont(ofSize: 14)
        syncLabel.textColor = UIColor(red: 0.4, green: 0.4, blue: 0.45, alpha: 1.0)
        syncLabel.textAlignment = .center
        syncLabel.backgroundColor = UIColor(red: 0.9, green: 0.9, blue: 0.92, alpha: 1.0)
        syncLabel.layer.cornerRadius = 8
        syncLabel.clipsToBounds = true
        syncLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(syncLabel)
        
        NSLayoutConstraint.activate([
            syncLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            syncLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            syncLabel.heightAnchor.constraint(equalToConstant: 32),
            syncLabel.widthAnchor.constraint(equalToConstant: 240)
        ])
        
        syncLabel.alpha = 0
        UIView.animate(withDuration: 0.3, animations: {
            syncLabel.alpha = 1
        }) { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                UIView.animate(withDuration: 0.3, animations: {
                    syncLabel.alpha = 0
                }) { _ in
                    syncLabel.removeFromSuperview()
                }
            }
        }
    }
    
    private func showSortPreferenceSyncError() {
        let errorLabel = UILabel()
        errorLabel.text = "排序偏好同步失败"
        errorLabel.font = UIFont.systemFont(ofSize: 14)
        errorLabel.textColor = UIColor.white
        errorLabel.textAlignment = .center
        errorLabel.backgroundColor = UIColor(red: 0.9, green: 0.3, blue: 0.3, alpha: 1.0)
        errorLabel.layer.cornerRadius = 8
        errorLabel.clipsToBounds = true
        errorLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(errorLabel)
        
        NSLayoutConstraint.activate([
            errorLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            errorLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            errorLabel.heightAnchor.constraint(equalToConstant: 32),
            errorLabel.widthAnchor.constraint(equalToConstant: 200)
        ])
        
        errorLabel.alpha = 0
        UIView.animate(withDuration: 0.3, animations: {
            errorLabel.alpha = 1
        }) { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                UIView.animate(withDuration: 0.3, animations: {
                    errorLabel.alpha = 0
                }) { _ in
                    errorLabel.removeFromSuperview()
                }
            }
        }
    }
}

// MARK: - UICollectionViewDataSource
extension PhotoGridViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
        let photo = photos[indexPath.item]
        let isSelected = selectedPhotos.contains { $0.localIdentifier == photo.localIdentifier }
        let selectionIndex = selectedPhotos.firstIndex { $0.localIdentifier == photo.localIdentifier }
        
        cell.configure(with: photo, isSelected: isSelected, selectionIndex: selectionIndex, isSelectionMode: isSelectionMode)
        cell.delegate = self
        
        return cell
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension PhotoGridViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let spacing: CGFloat = 2
        let availableWidth = collectionView.bounds.width - 16 - spacing * 4 // 减去左右边距和3个间距
        let itemWidth = availableWidth / 5
        return CGSize(width: itemWidth, height: itemWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
}

// MARK: - PhotoCellDelegate
extension PhotoGridViewController: PhotoCellDelegate {
    func photoCellTapped(_ cell: PhotoCell) {
        guard let indexPath = collectionView.indexPath(for: cell) else { return }
        let photo = photos[indexPath.item]
        
        if isSelectionMode {
            togglePhotoSelection(photo)
        }
    }
    
    private func togglePhotoSelection(_ photo: Photo) {
        if let index = selectedPhotos.firstIndex(where: { $0.localIdentifier == photo.localIdentifier }) {
            selectedPhotos.remove(at: index)
        } else {
            selectedPhotos.append(photo)
        }
        
        collectionView.reloadData()
    }
}




