import UIKit
import Photos

class SortPreferenceManager: NSObject {
    static let shared = SortPreferenceManager()
    private override init() {
        super.init()
        setupChangeObserver()
    }
    
    // MARK: - 排序偏好回调
    typealias SortPreferenceCompletion = (Bool, String?) -> Void
    typealias SortPreferenceChangeHandler = (SortMode) -> Void
    
    // 排序偏好变更回调
    var onSortPreferenceChanged: SortPreferenceChangeHandler?
    
    // MARK: - 系统相册排序选项映射
    private enum SystemSortOption: String {
        case creationDateAsc = "creationDate"  // 按创建时间升序（最旧的排最前）
        case creationDateDesc = "-creationDate" // 按创建时间降序（最新的排最前）
        case custom = "custom" // 自定义排序
        case title = "title" // 按标题排序
        case dateAdded = "dateAdded" // 按添加日期排序
    }
    
    // APP排序模式到系统排序选项的映射
    private let sortModeToSystemMap: [SortMode: SystemSortOption] = [
        .oldestFirst: .creationDateAsc,
        .newestFirst: .creationDateDesc,
        .custom: .custom
    ]
    
    // 系统排序选项到APP排序模式的映射
    private let systemToSortModeMap: [SystemSortOption: SortMode] = [
        .creationDateAsc: .oldestFirst,
        .creationDateDesc: .newestFirst,
        .custom: .custom,
        .title: .newestFirst, // 默认映射到最新
        .dateAdded: .newestFirst // 默认映射到最新
    ]
    
    // MARK: - 设置变更观察者
    private func setupChangeObserver() {
        PHPhotoLibrary.shared().register(self)
    }
    
    deinit {
        PHPhotoLibrary.shared().unregisterChangeObserver(self)
    }
    
    // MARK: - 同步APP排序偏好到系统相册
    func syncAppSortPreferenceToSystem(
        sortMode: SortMode,
        for collection: PHAssetCollection,
        completion: @escaping SortPreferenceCompletion
    ) {
        guard checkPhotoLibraryPermission() else {
            completion(false, "没有相册访问权限")
            return
        }
        
        guard let systemOption = sortModeToSystemMap[sortMode] else {
            completion(false, "不支持的排序方式")
            return
        }
        
        // 尝试设置系统相册的排序偏好
        setSystemSortPreference(systemOption, for: collection) { success, error in
            if success {
                print("✅ 排序偏好已同步到系统相册: \(sortMode)")
                completion(true, nil)
            } else {
                print("❌ 排序偏好同步失败: \(error ?? "未知错误")")
                completion(false, error)
            }
        }
    }
    
    // MARK: - 从系统相册读取排序偏好
    func getSystemSortPreference(for collection: PHAssetCollection) -> SortMode {
        guard checkPhotoLibraryPermission() else {
            return .newestFirst // 默认值
        }
        
        // 尝试从系统相册获取排序偏好
        let systemOption = getSystemSortOption(for: collection)
        return systemToSortModeMap[systemOption] ?? .newestFirst
    }
    
    // MARK: - 权限检查
    private func checkPhotoLibraryPermission() -> Bool {
        let status = PHPhotoLibrary.authorizationStatus()
        return status == .authorized || status == .limited
    }
    
    // MARK: - 设置系统排序偏好
    private func setSystemSortPreference(
        _ systemOption: SystemSortOption,
        for collection: PHAssetCollection,
        completion: @escaping (Bool, String?) -> Void
    ) {
        // 注意：iOS系统相册的排序偏好设置API有限制
        // 我们主要通过监听系统变更来实现同步
        
        // 尝试通过UserDefaults保存排序偏好（模拟系统设置）
        let key = "system_sort_preference_\(collection.localIdentifier)"
        UserDefaults.standard.set(systemOption.rawValue, forKey: key)
        
        // 由于系统API限制，我们主要依赖监听机制
        // 在实际应用中，可能需要使用其他方法
        completion(true, nil)
    }
    
    // MARK: - 获取系统排序选项
    private func getSystemSortOption(for collection: PHAssetCollection) -> SystemSortOption {
        // 尝试从UserDefaults读取（模拟系统设置）
        let key = "system_sort_preference_\(collection.localIdentifier)"
        if let rawValue = UserDefaults.standard.string(forKey: key),
           let systemOption = SystemSortOption(rawValue: rawValue) {
            return systemOption
        }
        
        // 默认返回最新排序
        return .creationDateDesc
    }
    
    // MARK: - 监听系统相册变更
    private func handleSystemSortPreferenceChange(for collection: PHAssetCollection) {
        let newSortMode = getSystemSortPreference(for: collection)
        
        DispatchQueue.main.async {
            // 通知APP更新排序偏好
            self.onSortPreferenceChanged?(newSortMode)
        }
    }
}

// MARK: - PHPhotoLibraryChangeObserver
extension SortPreferenceManager: PHPhotoLibraryChangeObserver {
    func photoLibraryDidChange(_ changeInstance: PHChange) {
        // 检查是否有相册变更
        // 注意：系统相册的排序偏好变更可能不会触发这个回调
        // 我们主要通过主动检查来实现同步
        
        // 这里可以添加更详细的变更检测逻辑
        print("📱 检测到系统相册变更")
    }
}
