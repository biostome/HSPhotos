import UIKit
import Photos

class PhotoSortManager {
    static let shared = PhotoSortManager()
    private init() {}
    
    // MARK: - 排序结果回调
    typealias SortCompletion = (Bool, String?) -> Void
    
    // MARK: - 核心排序方法
    func sortPhotosInCollection(
        collection: PHAssetCollection,
        selectedPhotoIds: [String],
        completion: @escaping SortCompletion
    ) {
        // 检查权限
        guard checkPhotoLibraryPermission() else {
            completion(false, "没有相册访问权限")
            return
        }
        
        // 第一步：获取当前相册的原始资产数组
        let originalAssets = getOriginalAssets(from: collection)
        
        // 第二步：获取按选择顺序排列的选中资产数组
        let selectedAssets = getSelectedAssets(from: originalAssets, selectedIds: selectedPhotoIds)
        
        // 第三步：计算排序后的目标资产顺序
        let newOrder = calculateNewOrder(originalAssets: originalAssets, selectedAssets: selectedAssets)
        
        // 第四步：对比originalAssets和newOrder，生成移动路径数组
        let moves = calculateMoves(originalAssets: originalAssets, newOrder: newOrder)
        
        // 第五步：通过performChanges提交moveAssets操作
        executeMoves(moves: moves, collection: collection, completion: completion)
    }
    
    // MARK: - 权限检查
    private func checkPhotoLibraryPermission() -> Bool {
        let status = PHPhotoLibrary.authorizationStatus()
        return status == .authorized || status == .limited
    }
    
    // MARK: - 第一步：获取原始资产数组
    private func getOriginalAssets(from collection: PHAssetCollection) -> [PHAsset] {
        let fetchOptions = PHFetchOptions()
        let fetchResult = PHAsset.fetchAssets(in: collection, options: fetchOptions)
        
        var assets: [PHAsset] = []
        fetchResult.enumerateObjects { asset, _, _ in
            assets.append(asset)
        }
        
        return assets
    }
    
    // MARK: - 第二步：获取选中资产数组
    private func getSelectedAssets(from originalAssets: [PHAsset], selectedIds: [String]) -> [PHAsset] {
        var selectedAssets: [PHAsset] = []
        
        for selectedId in selectedIds {
            if let asset = originalAssets.first(where: { $0.localIdentifier == selectedId }) {
                selectedAssets.append(asset)
            }
        }
        
        return selectedAssets
    }
    
    // MARK: - 第三步：计算新的排序顺序
    private func calculateNewOrder(originalAssets: [PHAsset], selectedAssets: [PHAsset]) -> [PHAsset] {
        guard let firstSelectedAsset = selectedAssets.first else {
            return originalAssets
        }
        
        // 找到第一张选中照片在原始数组中的位置作为锚点
        guard let anchorIndex = originalAssets.firstIndex(where: { $0.localIdentifier == firstSelectedAsset.localIdentifier }) else {
            return originalAssets
        }
        
        var newOrder: [PHAsset] = []
        var processedIds = Set<String>()
        
        // 1. 添加锚点之前的未选中照片
        for i in 0..<anchorIndex {
            let asset = originalAssets[i]
            if !selectedAssets.contains(where: { $0.localIdentifier == asset.localIdentifier }) {
                newOrder.append(asset)
                processedIds.insert(asset.localIdentifier)
            }
        }
        
        // 2. 按选择顺序添加所有选中的照片
        for selectedAsset in selectedAssets {
            newOrder.append(selectedAsset)
            processedIds.insert(selectedAsset.localIdentifier)
        }
        
        // 3. 添加剩余的未选中照片
        for asset in originalAssets {
            if !processedIds.contains(asset.localIdentifier) {
                newOrder.append(asset)
            }
        }
        
        return newOrder
    }
    
    // MARK: - 第四步：计算移动路径
    private func calculateMoves(originalAssets: [PHAsset], newOrder: [PHAsset]) -> [(from: Int, to: Int)] {
        var moves: [(from: Int, to: Int)] = []
        var currentAssets = originalAssets
        
        // 为每个目标位置计算移动
        for (targetIndex, targetAsset) in newOrder.enumerated() {
            // 找到目标资产在当前数组中的位置
            if let currentIndex = currentAssets.firstIndex(where: { $0.localIdentifier == targetAsset.localIdentifier }) {
                if currentIndex != targetIndex {
                    moves.append((from: currentIndex, to: targetIndex))
                    
                    // 更新当前数组（模拟移动操作）
                    let movedAsset = currentAssets.remove(at: currentIndex)
                    currentAssets.insert(movedAsset, at: targetIndex)
                }
            }
        }
        
        return moves
    }
    
    // MARK: - 第五步：执行移动操作
    private func executeMoves(
        moves: [(from: Int, to: Int)],
        collection: PHAssetCollection,
        completion: @escaping SortCompletion
    ) {
        // 如果没有需要移动的照片，直接返回成功
        if moves.isEmpty {
            completion(true, nil)
            return
        }
        
        PHPhotoLibrary.shared().performChanges({
            guard let changeRequest = PHAssetCollectionChangeRequest(for: collection) else {
                return
            }
            
            // 执行所有移动操作
            for move in moves {
                let indexSet = IndexSet(integer: move.from)
                changeRequest.moveAssets(at: indexSet, to: move.to)
            }
            
        }, completionHandler: { success, error in
            DispatchQueue.main.async {
                if success {
                    completion(true, nil)
                } else {
                    let errorMessage = error?.localizedDescription ?? "排序操作失败"
                    completion(false, errorMessage)
                }
            }
        })
    }
}
