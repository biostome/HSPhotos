import UIKit

protocol PhotoCellDelegate: AnyObject {
    func photoCellTapped(_ cell: PhotoCell)
}

class PhotoCell: UICollectionViewCell {
    weak var delegate: PhotoCellDelegate?
    
    private let imageView = UIImageView()
    private let selectionOverlay = UIView()
    private let selectionNumberLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        contentView.backgroundColor = .white
        contentView.layer.cornerRadius = 6
        contentView.clipsToBounds = true
        contentView.layer.shadowColor = UIColor.black.cgColor
        contentView.layer.shadowOffset = CGSize(width: 0, height: 1)
        contentView.layer.shadowRadius = 2
        contentView.layer.shadowOpacity = 0.1
        
        // Image View
        imageView.contentMode = .scaleAspectFill
        imageView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(imageView)
        
        // Selection Overlay
        selectionOverlay.backgroundColor = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 0.25)
        selectionOverlay.layer.cornerRadius = 6
        selectionOverlay.layer.borderWidth = 2
        selectionOverlay.layer.borderColor = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0).cgColor
        selectionOverlay.isHidden = true
        selectionOverlay.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(selectionOverlay)
        
        // Selection Number Label
        selectionNumberLabel.backgroundColor = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0)
        selectionNumberLabel.textColor = .white
        selectionNumberLabel.font = UIFont.systemFont(ofSize: 11, weight: .bold)
        selectionNumberLabel.textAlignment = .center
        selectionNumberLabel.layer.cornerRadius = 10
        selectionNumberLabel.clipsToBounds = true
        selectionNumberLabel.isHidden = true
        selectionNumberLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(selectionNumberLabel)
        
        // Tap Gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        contentView.addGestureRecognizer(tapGesture)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            
            selectionOverlay.topAnchor.constraint(equalTo: contentView.topAnchor),
            selectionOverlay.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            selectionOverlay.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            selectionOverlay.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            
            selectionNumberLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6),
            selectionNumberLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -6),
            selectionNumberLabel.widthAnchor.constraint(equalToConstant: 20),
            selectionNumberLabel.heightAnchor.constraint(equalToConstant: 20)
        ])
    }
    
    func configure(with photo: Photo, isSelected: Bool, selectionIndex: Int?, isSelectionMode: Bool) {
        imageView.image = photo.image ?? UIImage(systemName: "photo")
        
        if isSelectionMode {
            selectionOverlay.isHidden = !isSelected
            if isSelected, let index = selectionIndex {
                selectionNumberLabel.text = "\(index + 1)"
                selectionNumberLabel.isHidden = false
            } else {
                selectionNumberLabel.isHidden = true
            }
        } else {
            selectionOverlay.isHidden = true
            selectionNumberLabel.isHidden = true
        }
    }
    
    @objc private func handleTap() {
        delegate?.photoCellTapped(self)
    }
}
